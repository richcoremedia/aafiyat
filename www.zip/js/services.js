angular.module('starter.services', [])

.factory('Initialize', function() {
  
});
